fz80 ver.1.01 + (SUB+DAA) bugfix

The fz80.v is "Z80 CPU binary compatible soft core" written by Y.Kuwahara.
This core is much smaller than the core of other Z80 cores,
and a bus cycle is carried out with single clock like KC80 series.
This was made for the FPGA clone of PC8001(Japanese Classic PC).
http://www.geocities.jp/kwhr0/hard/pc8001.html

It can obtain the latest version from the following URL. 
But, it is written in Japanese. 
http://www.geocities.jp/kwhr0/hard/fz80.html

You must not distribute a source and netlist all or a part without permission.
Because, there is no definite license document here. 
Make contact from the following URL in Japanese if you need to modify or tell bug report.
http://www.geocities.jp/kwhr0/

------------------------------------------------
The fz80c.v is Z80 bus timing compatible wrapper for fz80.v.
This has the license which is different from fz80.v. 
Read the top of fz80c.v. 

Don't make inquiry about fz80c.v to Y.Kuwahara. 
------------------------------------------------

